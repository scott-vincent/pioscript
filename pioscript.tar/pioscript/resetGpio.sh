# Some pins are high when the Pi boots. This sets them low.
gpio reset
gpio mode 8 out
gpio write 8 0
gpio mode 9 out
gpio write 9 0
